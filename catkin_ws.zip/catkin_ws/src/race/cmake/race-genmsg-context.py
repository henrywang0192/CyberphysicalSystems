# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/nvidia/catkin_ws/src/race/msg/drive_param.msg;/home/nvidia/catkin_ws/src/race/msg/drive_values.msg;/home/nvidia/catkin_ws/src/race/msg/pid_input.msg"
services_str = ""
pkg_name = "race"
dependencies_str = "std_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "race;/home/nvidia/catkin_ws/src/race/msg;std_msgs;/opt/ros/kinetic/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/kinetic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
