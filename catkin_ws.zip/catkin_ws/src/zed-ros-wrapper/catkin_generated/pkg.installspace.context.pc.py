# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/usr/local/include".split(';') if "/usr/local/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rosconsole;sensor_msgs;opencv;image_transport;dynamic_reconfigure;tf2_ros;tf2_geometry_msgs;pcl_conversions".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "zed_wrapper"
PROJECT_SPACE_DIR = "/usr/local"
PROJECT_VERSION = "1.0.0"
