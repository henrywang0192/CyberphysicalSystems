# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/nvidia/catkin_ws/src/devel/include".split(';') if "/home/nvidia/catkin_ws/src/devel/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rosconsole;sensor_msgs;opencv;image_transport;dynamic_reconfigure;tf2_ros;tf2_geometry_msgs;pcl_conversions".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "zed_wrapper"
PROJECT_SPACE_DIR = "/home/nvidia/catkin_ws/src/devel"
PROJECT_VERSION = "1.0.0"
