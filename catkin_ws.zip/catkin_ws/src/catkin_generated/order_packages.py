# generated from catkin/cmake/template/order_packages.context.py.in
source_root_dir = "/home/nvidia/catkin_ws/src"
whitelisted_packages = "".split(';') if "" != "" else []
blacklisted_packages = "".split(';') if "" != "" else []
underlay_workspaces = "/home/nvidia/catkin_ws/devel;/opt/ros/kinetic".split(';') if "/home/nvidia/catkin_ws/devel;/opt/ros/kinetic" != "" else []
