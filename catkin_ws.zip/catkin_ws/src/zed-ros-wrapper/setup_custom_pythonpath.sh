# generated from dynamic_reconfigure/cmake/setup_custom_pythonpath.sh.in

PYTHONPATH=/home/nvidia/catkin_ws/src/devel/lib/python2.7/dist-packages:$PYTHONPATH
exec "$@"
